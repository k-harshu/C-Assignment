﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Linq1
{
    class Employee
    {
        public int EmployeeID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Title { get; set; }
        public DateTime DOB { get; set; }
        public DateTime DOJ { get; set; }
        public string City { get; set; }
    }
    class Program
    {
        public static List<Employee> empList = new List<Employee>
{ 
new Employee() {EmployeeID = 1001 , FirstName = " Malcolm ", LastName = " Daruwalla ", Title = " Manager ", DOB = DateTime.Parse(" 1984-01-02 "), DOJ = DateTime.Parse(" 2011-08-09 "), City = " Mumbai "},

new Employee() {EmployeeID = 1002 , FirstName = " Asdin ", LastName = " Dhalla ", Title = " AsstManager ", DOB = DateTime.Parse(" 1984-08-20 "), DOJ = DateTime.Parse(" 2012-7-7 "), City = " Mumbai "},

new Employee() {EmployeeID = 1003 , FirstName = " Madhavi ", LastName = " Oza ", Title = " Consultant ", DOB = DateTime.Parse(" 1987/11/14 "), DOJ = DateTime.Parse(" 2015/4/12 "), City = " Pune "},

new Employee() {EmployeeID = 1004 , FirstName = " Saba ",  LastName = " Shaikh ", Title = " SE ", DOB = DateTime.Parse(" 1990/6/3 "), DOJ = DateTime.Parse(" 2016/2/2 "), City = " Pune "},

new Employee() {EmployeeID = 1005 , FirstName = " Nazia ", LastName = " Shaikh ", Title = " SE ", DOB = DateTime.Parse(" 1991/3/8 "), DOJ = DateTime.Parse(" 2016/2/2 "), City = " Mumbai "},

new Employee() {EmployeeID = 1006 , FirstName = " Suresh ", LastName = " Pathak ", Title = " Consultant ", DOB = DateTime.Parse(" 1998/11/7 "), DOJ = DateTime.Parse(" 2014/8/8 "), City = " Chennai "},

new Employee() {EmployeeID = 1007 , FirstName = " Vijay ", LastName = " Natrajan ", Title = " Consultant ", DOB = DateTime.Parse(" 1989/12/2 "), DOJ = DateTime.Parse(" 2015/6/1 "), City = " Mumbai "},

new Employee() {EmployeeID = 1008 , FirstName = " Rahul ", LastName = " Dubey ", Title = " Associate ", DOB = DateTime.Parse(" 1993/11/11 "),  DOJ = DateTime.Parse(" 2014/11/6 "), City = " Chennai "},

new Employee() {EmployeeID = 1009 , FirstName = " Amit ", LastName = " Mistry ", Title = " Associate ", DOB = DateTime.Parse(" 1992/8/12 "), DOJ = DateTime.Parse(" 2014/12/3 "), City = " Chennai "},

new Employee() {EmployeeID = 1010 , FirstName = " Sumit ", LastName = " Shah ", Title = " Manager ", DOB = DateTime.Parse(" 1991/4/12 "), DOJ = DateTime.Parse(" 2016/1/2 "), City = " Pune "},

};

        public static void DisplayAll()
        {
            var displayallemployee = (from s in empList
                                      select s);
            foreach (var s in displayallemployee)
            {
                Console.WriteLine(s.EmployeeID + "" + s.FirstName + "" + s.LastName + "" + s.Title + "" + s.DOB + "" + s.DOJ + "" + s.City);
            }
        }
        public static void Notmumbai()
        {
            var NotMumbailist = (from s in empList where s.City != "Mumbai" select s);
            foreach (var s in NotMumbailist)
            {
                Console.WriteLine(s.EmployeeID + "" + s.FirstName + "" + s.LastName + "" + s.Title + "" + s.DOB + "" + s.DOJ + "" + s.City);
            }

        }
        public static void TitleAssesstemt()
        {
            var TitleAssesstemtlist = (from s in empList where s.Title == "AsstManager" select s);
            foreach (var s in TitleAssesstemtlist)
            {
                Console.WriteLine(s.EmployeeID + "" + s.FirstName + "" + s.LastName + "" + s.Title + "" + s.DOB + "" + s.DOJ + "" + s.City);
            }

        }

        static void Main(String[] args)
        {


            DisplayAll();
            Notmumbai();
            TitleAssesstemt();
            Console.ReadKey();



        }
    }
}