import { Component, OnInit } from '@angular/core';
import { User } from '../Model/User.model';
import { UserService } from '../Services/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list-user',
  templateUrl: './list-user.component.html',
  styleUrls: ['./list-user.component.css']
})
export class ListUserComponent implements OnInit {

  Users: User[];

  constructor(private router: Router, private UserService: UserService) { }

  // Initialize with default list of users
  ngOnInit() {
    if(localStorage.getItem("username")!=null){
     
    this.UserService.getUsers()
      .subscribe(data=> {
        this.Users = data;
      });
    }
    else
    this.router.navigate(['/login']);
    
  }

  // logOff user
  logOutUser():void{
      if(localStorage.getItem("username")!=null){
        localStorage.removeItem("username");
        this.router.navigate(['/login']);
      }
  }

// Delete User
deleteUser(user: User): void {
      let result = confirm('Do you want to delete the user?')
      if(result)
      {
        this.UserService.deleteUser(user.id)
          .subscribe( data => {
            this.Users = this.Users.filter(u => u !== user);
          });
        }
};

// Modify USer
editUser(user: User): void {
  localStorage.removeItem("editUserId");
  localStorage.setItem("editUserId", user.id.toString());
  this.router.navigate(['edit-user']);
};

// Add New User
addUser(): void {
  this.router.navigate(['add-user']);
};

}
