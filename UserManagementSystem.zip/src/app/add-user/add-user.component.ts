import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../Services/user.service';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit {

  addForm: FormGroup;
  submitted: boolean = false;
  

  constructor(private formBuilder: FormBuilder, private router: Router, 
    private UserService: UserService) { }

  ngOnInit() {
    this.addForm = this.formBuilder.group({
      id:[],
      firstName: ['', Validators.required],
      lastName:['', Validators.required],
      email: ['', Validators.required]
    });

  }

  onSubmit() {
    this.submitted = true;
    if(this.addForm.invalid){
      return;
    }
    this.UserService.createUser(this.addForm.value)
      .subscribe( data => {
        this.router.navigate(['list-user']);
      });
  }
}
